﻿
namespace Proj_BD
{
    partial class ComprasForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.gobackBtn = new System.Windows.Forms.Button();
            this.dataCompTxt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Type_ProdTxt = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.Nome_ProdTxt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.nome_fornTxt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ID_ProdTxt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.ID_CompraTxt = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.searchBtn = new System.Windows.Forms.Button();
            this.data_compraTXT = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.quantTXT = new System.Windows.Forms.TextBox();
            this.nomeFornTXT = new System.Windows.Forms.TextBox();
            this.nomeVendLbl = new System.Windows.Forms.Label();
            this.IDProdTXT = new System.Windows.Forms.TextBox();
            this.idProdLbl = new System.Windows.Forms.Label();
            this.quantLb = new System.Windows.Forms.Label();
            this.idCompraTXT = new System.Windows.Forms.TextBox();
            this.id_prodLbl = new System.Windows.Forms.Label();
            this.deleteBtn = new System.Windows.Forms.Button();
            this.addBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(14, 161);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 29;
            this.dataGridView1.Size = new System.Drawing.Size(1381, 467);
            this.dataGridView1.TabIndex = 43;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // gobackBtn
            // 
            this.gobackBtn.Location = new System.Drawing.Point(14, 688);
            this.gobackBtn.Name = "gobackBtn";
            this.gobackBtn.Size = new System.Drawing.Size(123, 33);
            this.gobackBtn.TabIndex = 64;
            this.gobackBtn.Text = "Go back";
            this.gobackBtn.UseVisualStyleBackColor = true;
            this.gobackBtn.Click += new System.EventHandler(this.gobackBtn_Click);
            // 
            // dataCompTxt
            // 
            this.dataCompTxt.Location = new System.Drawing.Point(158, 26);
            this.dataCompTxt.Name = "dataCompTxt";
            this.dataCompTxt.Size = new System.Drawing.Size(175, 27);
            this.dataCompTxt.TabIndex = 77;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(32, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(122, 20);
            this.label5.TabIndex = 76;
            this.label5.Text = "Data de Compra:";
            // 
            // Type_ProdTxt
            // 
            this.Type_ProdTxt.Location = new System.Drawing.Point(500, 82);
            this.Type_ProdTxt.Name = "Type_ProdTxt";
            this.Type_ProdTxt.Size = new System.Drawing.Size(175, 27);
            this.Type_ProdTxt.TabIndex = 75;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(370, 87);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(124, 20);
            this.label10.TabIndex = 74;
            this.label10.Text = "Tipo_de_Produto:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(669, 86);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(0, 20);
            this.label9.TabIndex = 73;
            // 
            // Nome_ProdTxt
            // 
            this.Nome_ProdTxt.Location = new System.Drawing.Point(940, 37);
            this.Nome_ProdTxt.Name = "Nome_ProdTxt";
            this.Nome_ProdTxt.Size = new System.Drawing.Size(204, 27);
            this.Nome_ProdTxt.TabIndex = 72;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(772, 40);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(112, 20);
            this.label7.TabIndex = 71;
            this.label7.Text = "Nome_Produto:";
            // 
            // nome_fornTxt
            // 
            this.nome_fornTxt.Location = new System.Drawing.Point(940, 86);
            this.nome_fornTxt.Name = "nome_fornTxt";
            this.nome_fornTxt.Size = new System.Drawing.Size(204, 27);
            this.nome_fornTxt.TabIndex = 70;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(772, 89);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(154, 20);
            this.label3.TabIndex = 69;
            this.label3.Text = "Nome do Fornecedor:";
            // 
            // ID_ProdTxt
            // 
            this.ID_ProdTxt.Location = new System.Drawing.Point(158, 86);
            this.ID_ProdTxt.Name = "ID_ProdTxt";
            this.ID_ProdTxt.Size = new System.Drawing.Size(175, 27);
            this.ID_ProdTxt.TabIndex = 68;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(32, 86);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(106, 20);
            this.label6.TabIndex = 67;
            this.label6.Text = "ID do Produto:";
            // 
            // ID_CompraTxt
            // 
            this.ID_CompraTxt.Location = new System.Drawing.Point(500, 29);
            this.ID_CompraTxt.Name = "ID_CompraTxt";
            this.ID_CompraTxt.Size = new System.Drawing.Size(175, 27);
            this.ID_CompraTxt.TabIndex = 66;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(370, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(105, 20);
            this.label8.TabIndex = 65;
            this.label8.Text = "ID da Compra:";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1297, 81);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(86, 33);
            this.button2.TabIndex = 79;
            this.button2.Text = "Clear";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // searchBtn
            // 
            this.searchBtn.Location = new System.Drawing.Point(1297, 34);
            this.searchBtn.Name = "searchBtn";
            this.searchBtn.Size = new System.Drawing.Size(86, 33);
            this.searchBtn.TabIndex = 78;
            this.searchBtn.Text = "Search";
            this.searchBtn.UseVisualStyleBackColor = true;
            this.searchBtn.Click += new System.EventHandler(this.searchBtn_Click);
            // 
            // data_compraTXT
            // 
            this.data_compraTXT.Location = new System.Drawing.Point(669, 716);
            this.data_compraTXT.Name = "data_compraTXT";
            this.data_compraTXT.Size = new System.Drawing.Size(91, 27);
            this.data_compraTXT.TabIndex = 91;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(547, 720);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(122, 20);
            this.label12.TabIndex = 90;
            this.label12.Text = "Data de Compra:";
            // 
            // quantTXT
            // 
            this.quantTXT.Location = new System.Drawing.Point(669, 667);
            this.quantTXT.Name = "quantTXT";
            this.quantTXT.Size = new System.Drawing.Size(91, 27);
            this.quantTXT.TabIndex = 89;
            // 
            // nomeFornTXT
            // 
            this.nomeFornTXT.Location = new System.Drawing.Point(985, 667);
            this.nomeFornTXT.Name = "nomeFornTXT";
            this.nomeFornTXT.Size = new System.Drawing.Size(175, 27);
            this.nomeFornTXT.TabIndex = 86;
            // 
            // nomeVendLbl
            // 
            this.nomeVendLbl.AutoSize = true;
            this.nomeVendLbl.Location = new System.Drawing.Point(825, 671);
            this.nomeVendLbl.Name = "nomeVendLbl";
            this.nomeVendLbl.Size = new System.Drawing.Size(154, 20);
            this.nomeVendLbl.TabIndex = 85;
            this.nomeVendLbl.Text = "Nome do Fornecedor:";
            // 
            // IDProdTXT
            // 
            this.IDProdTXT.Location = new System.Drawing.Point(349, 716);
            this.IDProdTXT.Name = "IDProdTXT";
            this.IDProdTXT.Size = new System.Drawing.Size(175, 27);
            this.IDProdTXT.TabIndex = 84;
            // 
            // idProdLbl
            // 
            this.idProdLbl.AutoSize = true;
            this.idProdLbl.Location = new System.Drawing.Point(226, 720);
            this.idProdLbl.Name = "idProdLbl";
            this.idProdLbl.Size = new System.Drawing.Size(106, 20);
            this.idProdLbl.TabIndex = 83;
            this.idProdLbl.Text = "ID do Produto:";
            // 
            // quantLb
            // 
            this.quantLb.AutoSize = true;
            this.quantLb.Location = new System.Drawing.Point(547, 670);
            this.quantLb.Name = "quantLb";
            this.quantLb.Size = new System.Drawing.Size(90, 20);
            this.quantLb.TabIndex = 82;
            this.quantLb.Text = "Quantidade:";
            // 
            // idCompraTXT
            // 
            this.idCompraTXT.Location = new System.Drawing.Point(349, 667);
            this.idCompraTXT.Name = "idCompraTXT";
            this.idCompraTXT.Size = new System.Drawing.Size(175, 27);
            this.idCompraTXT.TabIndex = 81;
            // 
            // id_prodLbl
            // 
            this.id_prodLbl.AutoSize = true;
            this.id_prodLbl.Location = new System.Drawing.Point(226, 671);
            this.id_prodLbl.Name = "id_prodLbl";
            this.id_prodLbl.Size = new System.Drawing.Size(105, 20);
            this.id_prodLbl.TabIndex = 80;
            this.id_prodLbl.Text = "ID da Compra:";
            // 
            // deleteBtn
            // 
            this.deleteBtn.Location = new System.Drawing.Point(1286, 719);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(109, 33);
            this.deleteBtn.TabIndex = 93;
            this.deleteBtn.Text = "Delete Txt Boxs";
            this.deleteBtn.UseVisualStyleBackColor = true;
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // addBtn
            // 
            this.addBtn.Location = new System.Drawing.Point(1286, 661);
            this.addBtn.Name = "addBtn";
            this.addBtn.Size = new System.Drawing.Size(109, 33);
            this.addBtn.TabIndex = 92;
            this.addBtn.Text = "Add";
            this.addBtn.UseVisualStyleBackColor = true;
            this.addBtn.Click += new System.EventHandler(this.addBtn_Click);
            // 
            // ComprasForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1440, 774);
            this.Controls.Add(this.deleteBtn);
            this.Controls.Add(this.addBtn);
            this.Controls.Add(this.data_compraTXT);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.quantTXT);
            this.Controls.Add(this.nomeFornTXT);
            this.Controls.Add(this.nomeVendLbl);
            this.Controls.Add(this.IDProdTXT);
            this.Controls.Add(this.idProdLbl);
            this.Controls.Add(this.quantLb);
            this.Controls.Add(this.idCompraTXT);
            this.Controls.Add(this.id_prodLbl);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.searchBtn);
            this.Controls.Add(this.dataCompTxt);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Type_ProdTxt);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.Nome_ProdTxt);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.nome_fornTxt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ID_ProdTxt);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.ID_CompraTxt);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.gobackBtn);
            this.Controls.Add(this.dataGridView1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "ComprasForm";
            this.Text = "Compras";
            this.Load += new System.EventHandler(this.ComprasForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button gobackBtn;
        private System.Windows.Forms.TextBox dataCompTxt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Type_ProdTxt;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox Nome_ProdTxt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox nome_fornTxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox ID_ProdTxt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox ID_CompraTxt;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button searchBtn;
        private System.Windows.Forms.TextBox data_compraTXT;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox quantTXT;
        private System.Windows.Forms.TextBox nomeFornTXT;
        private System.Windows.Forms.Label nomeVendLbl;
        private System.Windows.Forms.TextBox IDProdTXT;
        private System.Windows.Forms.Label idProdLbl;
        private System.Windows.Forms.Label quantLb;
        private System.Windows.Forms.TextBox idCompraTXT;
        private System.Windows.Forms.Label id_prodLbl;
        private System.Windows.Forms.Button deleteBtn;
        private System.Windows.Forms.Button addBtn;
    }
}